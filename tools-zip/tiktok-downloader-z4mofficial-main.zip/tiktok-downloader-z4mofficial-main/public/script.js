
/* TikTok Downloader - Z4M.OFFICIAL */
(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);

  const form = $("downloadForm");
  const input = $("urlInput");
  const button = $("downloadBtn");
  const loader = $("loader");
  const notice = $("notice");
  const result = $("resultArea");

  let photoUrls = [];
  let activePhoto = 0;

  const year = $("year");
  if (year) year.textContent = new Date().getFullYear();

  function message(text, type = "error") {
    notice.textContent = text;
    notice.className = `notice ${type}`;
  }

  function clearMessage() {
    notice.textContent = "";
    notice.className = "notice hidden";
  }

  function loading(on) {
    button.disabled = on;
    button.innerHTML = on
      ? '<i class="fa-solid fa-spinner fa-spin"></i><span>Memproses...</span>'
      : '<i class="fa-solid fa-wand-magic-sparkles"></i><span>Proses Video</span><i class="fa-solid fa-arrow-right btn-arrow"></i>';
    loader.classList.toggle("hidden", !on);
  }

  function safeUrl(value) {
    if (typeof value !== "string") return "";
    try {
      const u = new URL(value);
      return ["https:", "http:"].includes(u.protocol) ? u.href : "";
    } catch {
      return "";
    }
  }

  function fmt(value) {
    if (value === undefined || value === null || value === "") return "—";
    if (typeof value === "number") return value.toLocaleString("id-ID");
    return String(value);
  }

  function getFileUrl(value) {
    if (typeof value === "string") return safeUrl(value);
    if (value && typeof value === "object") {
      return safeUrl(value.url || value.play || value.download || value.src);
    }
    return "";
  }

  async function forceDownload(url, filename) {
    url = safeUrl(url);
    if (!url) {
      message("Link file download tidak valid.");
      return;
    }

    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    a.referrerPolicy = "no-referrer";
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  function hideMedia() {
    [
      "videoContainer", "photoContainer", "sliderTrack",
      "photoControls", "btnVideoNowm", "btnAudio", "downloadAllBtn"
    ].forEach(id => $(id).classList.add("hidden"));

    $("photoContainer").replaceChildren();
    $("sliderTrack").replaceChildren();
    $("videoPlayer").pause();
    $("videoPlayer").removeAttribute("src");
    $("videoPlayer").load();
  }

  function renderPhotos(slides) {
    const box = $("photoContainer");
    const track = $("sliderTrack");
    const controls = $("photoControls");

    photoUrls = slides.map(item => {
      if (typeof item === "string") return safeUrl(item);
      return getFileUrl(item);
    }).filter(Boolean);

    activePhoto = 0;
    if (!photoUrls.length) return;

    photoUrls.forEach((url, i) => {
      const img = document.createElement("img");
      img.src = url;
      img.alt = `Foto TikTok ${i + 1}`;
      img.loading = "lazy";
      img.style.display = i === 0 ? "block" : "none";
      box.appendChild(img);

      const thumbButton = document.createElement("button");
      thumbButton.type = "button";
      thumbButton.className = i === 0 ? "active" : "";
      thumbButton.setAttribute("aria-label", `Lihat foto ${i + 1}`);

      const thumb = document.createElement("img");
      thumb.src = url;
      thumb.alt = "";
      thumb.loading = "lazy";
      thumbButton.appendChild(thumb);

      thumbButton.addEventListener("click", () => {
        activePhoto = i;
        [...box.children].forEach((el, n) => {
          el.style.display = n === i ? "block" : "none";
        });
        [...track.children].forEach((el, n) => {
          el.classList.toggle("active", n === i);
        });
        $("slideCounter").textContent = `${i + 1} / ${photoUrls.length}`;
      });

      track.appendChild(thumbButton);
    });

    box.classList.remove("hidden");
    track.classList.remove("hidden");
    controls.classList.remove("hidden");
    $("downloadAllBtn").classList.remove("hidden");
    $("slideCounter").textContent = `1 / ${photoUrls.length}`;
    $("resType").textContent = "Foto";
  }

  function renderResult(data) {
    if (!data || typeof data !== "object") {
      throw new Error("Respons API tidak valid.");
    }

    if (data.error) {
      throw new Error(typeof data.error === "string"
        ? data.error : "API gagal memproses video.");
    }

    hideMedia();

    $("resUsername").textContent =
      fmt(data.username || data.author?.nickname || data.author?.name || "TikTok Creator");
    $("resViews").textContent = `${fmt(data.views)} views`;
    $("resLikes").textContent = fmt(data.likes);
    $("resDownloads").textContent = "Siap";

    // Format API downloader lama
    const downloads = data.downloads || {};
    const nowmList = Array.isArray(downloads.nowm) ? downloads.nowm : [];
    const wmList = Array.isArray(downloads.wm) ? downloads.wm : [];

    const videoUrl = getFileUrl(nowmList[0]) || getFileUrl(wmList[0]);
    const audioList = Array.isArray(data.mp3) ? data.mp3 : [];
    const audioUrl = getFileUrl(audioList[0]);

    const slides = Array.isArray(data.slides) ? data.slides : [];
    const type = String(data.type || "").toLowerCase();

    if (slides.length || type === "photo") {
      renderPhotos(slides);
    }

    if (videoUrl) {
      const videoButton = $("btnVideoNowm");
      videoButton.href = videoUrl;
      videoButton.classList.remove("hidden");

      $("videoPlayer").src = videoUrl;
      $("videoContainer").classList.remove("hidden");
      $("resType").textContent = slides.length ? "Foto + Video" : "Video";
    }

    if (audioUrl) {
      $("btnAudio").href = audioUrl;
      $("btnAudio").classList.remove("hidden");
    }

    if (!videoUrl && !audioUrl && !photoUrls.length) {
      throw new Error(
        "Link download tidak ditemukan dalam respons API. Periksa format respons api/download.js."
      );
    }

    result.classList.remove("hidden");
    message("Berhasil diproses. Pilih file yang ingin kamu simpan.", "success");
  }

  async function fetchData() {
    const raw = input.value.trim();
    if (!raw) {
      message("Masukkan link TikTok terlebih dahulu.");
      input.focus();
      return;
    }

    let parsed;
    try {
      parsed = new URL(raw);
    } catch {
      message("Link tidak valid. Salin ulang link TikTok.");
      return;
    }

    const host = parsed.hostname.toLowerCase();
    const isTikTok = host === "tiktok.com" || host.endsWith(".tiktok.com");

    if (!isTikTok) {
      message("Masukkan link dari TikTok, termasuk vt.tiktok.com atau vm.tiktok.com.");
      return;
    }

    loading(true);
    clearMessage();
    result.classList.add("hidden");

    try {
      // Pertahankan metode GET endpoint API yang lama
      const response = await fetch(
        `/api/download?url=${encodeURIComponent(raw)}`,
        { method: "GET", headers: { Accept: "application/json" } }
      );

      const body = await response.text();
      let data;

      try {
        data = JSON.parse(body);
      } catch {
        throw new Error(
          `Respons API bukan JSON (HTTP ${response.status}). Periksa endpoint /api/download.`
        );
      }

      if (!response.ok) {
        throw new Error(
          data.error || data.message || `API error: HTTP ${response.status}`
        );
      }

      renderResult(data);
    } catch (err) {
      console.error("[Z4M Downloader]", err);
      result.classList.add("hidden");
      message(err.message || "Gagal memproses video. Coba lagi.");
    } finally {
      loading(false);
    }
  }

  form.addEventListener("submit", event => {
    event.preventDefault();
    fetchData();
  });

  $("clearBtn").addEventListener("click", () => {
    input.value = "";
    result.classList.add("hidden");
    hideMedia();
    clearMessage();
    input.focus();
  });

  $("btnVideoNowm").addEventListener("click", event => {
    event.preventDefault();
    forceDownload($("btnVideoNowm").href, "z4m-tiktok-video.mp4");
  });

  $("btnAudio").addEventListener("click", event => {
    event.preventDefault();
    forceDownload($("btnAudio").href, "z4m-tiktok-audio.mp3");
  });

  $("btnDownloadCurrentSlide").addEventListener("click", () => {
    if (photoUrls[activePhoto]) {
      forceDownload(photoUrls[activePhoto], `z4m-tiktok-photo-${activePhoto + 1}.jpg`);
    }
  });

  $("downloadAllBtn").addEventListener("click", async () => {
    for (let i = 0; i < photoUrls.length; i++) {
      await forceDownload(photoUrls[i], `z4m-tiktok-photo-${i + 1}.jpg`);
      if (i < photoUrls.length - 1) {
        await new Promise(resolve => setTimeout(resolve, 700));
      }
    }
  });
})();

                                        
