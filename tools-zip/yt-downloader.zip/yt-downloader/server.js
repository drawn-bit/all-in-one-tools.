// Server untuk YouTube Downloader. Taruh file scraper kamu di folder yang sama dengan nama: yttmp3.js
const express = require("express");
const path = require("path");
const { getVideoInfo, downloadMp3, downloadMp4 } = require("./yttmp3");

const app = express();
app.use(express.static(path.join(__dirname, "public")));

const YT_REGEX = /^(https?:\/\/)?(www\.|m\.|music\.)?(youtube\.com|youtu\.be)\/.+/i;
const valid = (u) => typeof u === "string" && YT_REGEX.test(u.trim());

app.get("/api/info", async (req, res) => {
  const url = req.query.url;
  if (!valid(url)) return res.status(400).json({ status: false, message: "Link YouTube tidak valid." });
  try {
    const { data } = await getVideoInfo(url);
    const qualities = [...new Set((data.video_formats || []).map((f) => String(f.quality || f.height)))]
      .filter((q) => /^\d+$/.test(q))
      .sort((a, b) => a - b);
    res.json({
      status: true,
      id: data.id,
      title: data.title,
      thumbnail: data.thumbnail || `https://i.ytimg.com/vi/${data.id}/hqdefault.jpg`,
      durationLabel: data.durationLabel || data.duration,
      qualities: qualities.length ? qualities : ["360", "480", "720", "1080"],
    });
  } catch (e) {
    res.status(500).json({ status: false, message: e.message });
  }
});

app.get("/api/download", async (req, res) => {
  const { url, type = "mp3", quality = "720" } = req.query;
  if (!valid(url)) return res.status(400).json({ status: false, message: "Link YouTube tidak valid." });
  try {
    const result = type === "mp4" ? await downloadMp4(url, String(quality)) : await downloadMp3(url);
    res.json(result);
  } catch (e) {
    res.status(500).json({ status: false, message: e.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`YT Downloader jalan di http://localhost:${PORT}`));
