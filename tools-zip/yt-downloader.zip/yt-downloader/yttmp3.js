/**
 * YTMP3 (yttmp3.com.co) YouTube to MP3 & MP4 Converter / Downloader Scraper
 * Author: Vamz Spectre (Vamx)
 * Target: yttmp3.com.co (Engine: savetube.vip reverse engineered)
 * Decryption: AES-128-CBC
 */

const crypto = require("crypto");
const axios = require("axios");

const AES_KEY = Buffer.from("C5D58EF67A7584E4A29F6C35BBC4EB12", "hex");
const DEFAULT_HEADERS = {
  "Content-Type": "application/json",
  Origin: "https://yttmp3.com.co",
  Referer: "https://yttmp3.com.co/",
  "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
};

async function getRandomCdn() {
  try {
    const res = await axios.get("https://media.savetube.vip/api/random-cdn", {
      headers: DEFAULT_HEADERS,
      timeout: 10000,
    });
    if (res.data && res.data.cdn) return res.data.cdn;
    return "cdn401.savetube.vip";
  } catch {
    return "cdn401.savetube.vip";
  }
}

function decryptPayload(base64Data) {
  try {
    const rawBuffer = Buffer.from(base64Data.replace(/\s/g, ""), "base64");
    if (rawBuffer.length < 16) {
      throw new Error("Invalid payload: buffer length less than 16 bytes");
    }
    const iv = rawBuffer.subarray(0, 16);
    const ciphertext = rawBuffer.subarray(16);
    const decipher = crypto.createDecipheriv("aes-128-cbc", AES_KEY, iv);
    let decrypted = decipher.update(ciphertext);
    decrypted = Buffer.concat([decrypted, decipher.final()]);
    return JSON.parse(decrypted.toString("utf8"));
  } catch (err) {
    throw new Error(`Gagal mendekripsi payload YTMP3: ${err.message}`);
  }
}

async function getVideoInfo(youtubeUrl, cdnHost = null) {
  if (!youtubeUrl || typeof youtubeUrl !== "string") {
    throw new Error("YouTube URL diperlukan");
  }
  const cdn = cdnHost || (await getRandomCdn());
  const res = await axios.post(
    `https://${cdn}/v2/info`,
    { url: youtubeUrl.trim() },
    { headers: DEFAULT_HEADERS, timeout: 20000 }
  );
  const body = res.data;
  if (!body || body.status === false || !body.data) {
    throw new Error(body?.message || "Gagal mengambil data video dari YTMP3");
  }
  const videoData = decryptPayload(body.data);
  return { cdn, data: videoData };
}

async function getDownloadUrl({ key, titleSlug = "", quality = "128", type = "audio", directUrl = null, cdnHost = null }) {
  const cdn = cdnHost || (await getRandomCdn());

  if (directUrl && type !== "audio") {
    return {
      status: true,
      downloadUrl: `${directUrl}&title=${titleSlug || "video"}-ytshorts.savetube.vip`,
    };
  }

  const downloadType = type === "audio" || quality === "128" ? "audio" : "video";
  const postData = { downloadType, quality: String(quality), key };

  const res = await axios.post(`https://${cdn}/download`, postData, {
    headers: DEFAULT_HEADERS,
    timeout: 25000,
  });

  const body = res.data;
  if (!body || body.status === false || !body.data?.downloadUrl) {
    throw new Error(body?.message || "Gagal mendapatkan download link dari YTMP3");
  }
  return { status: true, downloadUrl: body.data.downloadUrl };
}

async function uploadToVamxCdn(fileUrl, filename = "media.mp3") {
  if (!fileUrl || !fileUrl.startsWith("http")) return fileUrl;
  try {
    const res = await fetch(fileUrl, { headers: { "User-Agent": DEFAULT_HEADERS["User-Agent"] } });
    if (!res.ok) return fileUrl;
    const arrayBuffer = await res.arrayBuffer();
    const contentType = res.headers.get("content-type") || "application/octet-stream";
    const blob = new Blob([arrayBuffer], { type: contentType });
    const form = new FormData();
    form.append("file", blob, filename);
    const uploadRes = await fetch("https://cdn.vamxapi.my.id/api/v1/media/upload", {
      method: "POST",
      headers: { "x-client-mode": "vamx-cdn" },
      body: form,
    });
    const json = await uploadRes.json();
    if (json.status && json.result?.media?.url) return json.result.media.url;
  } catch {
    // Fallback jika upload CDN gagal
  }
  return fileUrl;
}

async function downloadMp3(youtubeUrl, options = {}) {
  const { cdn, data } = await getVideoInfo(youtubeUrl);
  const dl = await getDownloadUrl({
    key: data.key,
    titleSlug: data.titleSlug,
    quality: "128",
    type: "audio",
    cdnHost: cdn,
  });

  let audioUrl = dl.downloadUrl;
  let thumbUrl = data.thumbnail;

  if (options.saveToCdn) {
    audioUrl = await uploadToVamxCdn(audioUrl, `${data.titleSlug || "audio"}.mp3`);
    if (thumbUrl) thumbUrl = await uploadToVamxCdn(thumbUrl, `thumb_${data.id}.webp`);
  }

  return {
    status: true,
    title: data.title,
    id: data.id,
    duration: data.duration,
    durationLabel: data.durationLabel,
    thumbnail: thumbUrl,
    type: "audio",
    format: "mp3",
    quality: "320kbps",
    downloadUrl: audioUrl,
  };
}

async function downloadMp4(youtubeUrl, quality = "720", options = {}) {
  const { cdn, data } = await getVideoInfo(youtubeUrl);

  let directUrl = null;
  if (data.video_formats && Array.isArray(data.video_formats)) {
    const match = data.video_formats.find(
      (f) => String(f.quality) === String(quality) || String(f.height) === String(quality)
    );
    if (match && match.url) directUrl = match.url;
  }

  const dl = await getDownloadUrl({
    key: data.key,
    titleSlug: data.titleSlug,
    quality: String(quality),
    type: "video",
    directUrl,
    cdnHost: cdn,
  });

  let videoUrl = dl.downloadUrl;
  let thumbUrl = data.thumbnail;

  if (options.saveToCdn) {
    videoUrl = await uploadToVamxCdn(videoUrl, `${data.titleSlug || "video"}_${quality}p.mp4`);
    if (thumbUrl) thumbUrl = await uploadToVamxCdn(thumbUrl, `thumb_${data.id}.webp`);
  }

  return {
    status: true,
    title: data.title,
    id: data.id,
    duration: data.duration,
    durationLabel: data.durationLabel,
    thumbnail: thumbUrl,
    type: "video",
    format: "mp4",
    quality: `${quality}p`,
    downloadUrl: videoUrl,
  };
}

async function scrapeYttmp3(youtubeUrl, options = {}) {
  const { cdn, data } = await getVideoInfo(youtubeUrl);

  const mp3Dl = await getDownloadUrl({
    key: data.key,
    titleSlug: data.titleSlug,
    quality: "128",
    type: "audio",
    cdnHost: cdn,
  });

  const availableVideoQualities = (data.video_formats || []).map((f) => String(f.quality || f.height));
  const preferredQuality = ["720", "1080", "480", "360"].find((q) => availableVideoQualities.includes(q)) || "720";

  let directUrl = null;
  const matchFmt = (data.video_formats || []).find((f) => String(f.quality || f.height) === preferredQuality);
  if (matchFmt && matchFmt.url) directUrl = matchFmt.url;

  const mp4Dl = await getDownloadUrl({
    key: data.key,
    titleSlug: data.titleSlug,
    quality: preferredQuality,
    type: "video",
    directUrl,
    cdnHost: cdn,
  });

  let audioUrl = mp3Dl.downloadUrl;
  let videoUrl = mp4Dl.downloadUrl;
  let thumbUrl = data.thumbnail;

  if (options.saveToCdn) {
    audioUrl = await uploadToVamxCdn(audioUrl, `${data.titleSlug || "audio"}.mp3`);
    videoUrl = await uploadToVamxCdn(videoUrl, `${data.titleSlug || "video"}_${preferredQuality}p.mp4`);
    if (thumbUrl) thumbUrl = await uploadToVamxCdn(thumbUrl, `thumb_${data.id}.webp`);
  }

  return {
    status: true,
    result: {
      id: data.id,
      title: data.title,
      titleSlug: data.titleSlug,
      url: data.url,
      thumbnail: thumbUrl,
      duration: data.duration,
      durationLabel: data.durationLabel,
      mp3: { format: "mp3", quality: "320kbps", downloadUrl: audioUrl },
      mp4: { format: "mp4", quality: `${preferredQuality}p`, downloadUrl: videoUrl },
      availableQualities: {
        audio: ["128 (MP3 320kbps)"],
        video: availableVideoQualities.filter((v, i, a) => a.indexOf(v) === i),
      },
    },
  };
}

module.exports = {
  getRandomCdn,
  decryptPayload,
  getVideoInfo,
  getDownloadUrl,
  downloadMp3,
  downloadMp4,
  scrapeYttmp3,
};
