# Vexora FB Downloader

Halaman: index.html
Backend (Vercel Functions): api/fb-info.js dan api/fb-dl.js (masing-masing berdiri sendiri)

## Cara 1 (paling aman): deploy sebagai project Vercel sendiri
1. Upload semua file ke repo GitHub baru (index.html dan folder api/ di paling atas repo).
2. Vercel > Add New Project > pilih repo > Framework Preset: Other > Deploy.
3. Buka https://nama-project.vercel.app

## Cara 2: ditaruh di project Vercel yang sudah ada (hub)
- Salin api/fb-info.js dan api/fb-dl.js ke folder api/ di ROOT repo hub (bukan di dalam subfolder).
- Halaman index.html boleh ditaruh di mana saja.
- Kalau halaman ada di project/domain lain, isi API_BASE di index.html dengan alamat project yang punya folder api/.

## Jalan lokal (Termux / PC)
node server.js -> http://localhost:3000 (Node.js 18+)

Downloader core: Vamz Spectre (MIT)
Made in by Vexora Tools
