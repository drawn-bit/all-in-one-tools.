# Vexora FB Downloader

## Deploy ke Vercel (GitHub)
1. Upload SEMUA file ini ke repo GitHub, dengan struktur:
   index.html, vercel.json, package.json, api/info.js, api/dl.js, lib/fb.js, server.js
   File index.html, api/, dan vercel.json harus ada di folder paling atas repo
   (atau atur "Root Directory" di Vercel ke folder tempat file-file itu berada).
2. Import repo di Vercel. Framework Preset: Other. Build Command dan Output Directory dikosongkan.
3. Deploy. Buka https://nama-project.vercel.app

Kalau tools ini ditaruh di dalam project Vercel lain (misal hub Vexora Tools), folder api/, lib/, dan vercel.json
harus ada di root project itu juga.

## Jalan lokal (Termux / PC)
node server.js -> buka http://localhost:3000 (Node.js 18+)

## Kalau gagal
- Video harus publik.
- Kalau Facebook mengubah halamannya, perbarui regex di lib/fb.js.

Downloader core: Vamz Spectre (MIT)
Made in by Vexora Tools
