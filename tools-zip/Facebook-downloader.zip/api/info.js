const { downloadFacebook } = require("../lib/fb");

module.exports = async (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Cache-Control", "no-store");
  const url = req.query && req.query.url;
  const data = await downloadFacebook(url);
  res.status(data.status ? 200 : 400).json(data);
};
