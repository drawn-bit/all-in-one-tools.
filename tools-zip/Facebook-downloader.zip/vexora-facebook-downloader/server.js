/**
 * Facebook Video & Reels Downloader - Web UI
 * Downloader core: Vamz Spectre (MIT) | UI & server: Vexora Tools
 * Jalankan: node server.js  ->  buka http://localhost:3000
 * Butuh Node.js 18+ (tanpa npm install)
 */
const http = require("http");
const fs = require("fs");
const path = require("path");
const { Readable } = require("stream");

const PORT = process.env.PORT || 3000;

/* ====== KODE DOWNLOADER (dari Vamz Spectre) ====== */
function decodeFbUrl(raw) {
  if (!raw) return "";
  try { return JSON.parse(`"${raw}"`); }
  catch {
    return raw.replace(/\\u0025/g, "%").replace(/\\u0026/g, "&")
      .replace(/\\u002F/gi, "/").replace(/\\\//g, "/").replace(/&amp;/g, "&");
  }
}
function decodeHtmlEntities(str) {
  if (!str) return "";
  return str
    .replace(/&#x([0-9a-fA-F]+);/g, (_, h) => String.fromCharCode(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, d) => String.fromCharCode(parseInt(d, 10)))
    .replace(/&amp;/g, "&").replace(/&quot;/g, '"')
    .replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&nbsp;/g, " ");
}
function normalizeFacebookUrl(url) {
  const u = url.trim();
  const m = u.match(/(?:facebook\.com|fb\.watch)\/reel\/(\d+)/i);
  return m && m[1] ? `https://www.facebook.com/watch/?v=${m[1]}` : u;
}
async function downloadFacebook(fbUrl) {
  const fail = (message) => ({ status: false, message });
  if (!fbUrl || typeof fbUrl !== "string") return fail("Link Facebook wajib diisi.");
  const cleanUrl = normalizeFacebookUrl(fbUrl);
  if (!/facebook\.com|fb\.watch/i.test(cleanUrl))
    return fail("Link tidak valid. Harus dari facebook.com atau fb.watch.");

  const headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
    "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
    "Sec-Ch-Ua": '"Not(A:Brand";v="99", "Google Chrome";v="133", "Chromium";v="133"',
    "Sec-Ch-Ua-Mobile": "?0", "Sec-Ch-Ua-Platform": '"Windows"',
    "Sec-Fetch-Dest": "document", "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none", "Sec-Fetch-User": "?1", "Upgrade-Insecure-Requests": "1"
  };
  try {
    const res = await fetch(cleanUrl, { headers, redirect: "follow" });
    if (!res.ok) return fail(`Gagal memuat halaman Facebook (HTTP ${res.status})`);
    const html = await res.text();

    const hdMatch = html.match(/"browser_native_hd_url":"([^"]+)"/) || html.match(/"playable_url_quality_hd":"([^"]+)"/) ||
      html.match(/"hd_src":"([^"]+)"/) || html.match(/"hd_src_no_ratelimit":"([^"]+)"/);
    let hdUrl = hdMatch && hdMatch[1] ? decodeFbUrl(hdMatch[1]) : "";

    const sdMatch = html.match(/"browser_native_sd_url":"([^"]+)"/) || html.match(/"playable_url":"([^"]+)"/) ||
      html.match(/"sd_src":"([^"]+)"/) || html.match(/"sd_src_no_ratelimit":"([^"]+)"/);
    let sdUrl = sdMatch && sdMatch[1] ? decodeFbUrl(sdMatch[1]) : "";

    if (!hdUrl && !sdUrl) {
      const og = html.match(/<meta\s+property="og:video"\s+content="([^"]+)"/i) ||
        html.match(/<meta\s+content="([^"]+)"\s+property="og:video"/i) ||
        html.match(/"video":\s*\[\s*\{\s*"url":\s*"([^"]+)"/i);
      if (og && og[1]) sdUrl = decodeFbUrl(og[1]);
    }
    if (!hdUrl && !sdUrl)
      return fail("Video tidak ditemukan. Pastikan video publik dan link masih aktif.");

    const tm = html.match(/<meta\s+property="og:title"\s+content="([^"]+)"/i) || html.match(/<title>([^<]+)<\/title>/i);
    const title = tm && tm[1] ? decodeHtmlEntities(decodeFbUrl(tm[1].replace(/ \| Facebook$/i, "").trim())) : "";

    const thm = html.match(/<meta\s+property="og:image"\s+content="([^"]+)"/i) ||
      html.match(/"preferred_thumbnail":{"image":{"uri":"([^"]+)"/i);
    const thumbnail = thm && thm[1] ? decodeHtmlEntities(decodeFbUrl(thm[1])) : "";

    const dm = html.match(/"playable_duration_in_ms":(\d+)/);
    const duration = dm && dm[1] ? Math.round(Number(dm[1]) / 1000) : null;

    const medias = [];
    if (hdUrl) medias.push({ quality: "HD", url: hdUrl });
    if (sdUrl) medias.push({ quality: "SD", url: sdUrl });

    return { status: true, result: { title: title || "Facebook Video", duration, thumbnail: thumbnail || null, medias } };
  } catch (err) {
    return fail(err.message || "Terjadi kesalahan saat memproses video Facebook");
  }
}
/* ====== AKHIR KODE DOWNLOADER ====== */

const ALLOWED_HOSTS = /(^|\.)(fbcdn\.net|facebook\.com|fbsbx\.com)$/i;

function sendJson(res, code, obj) {
  res.writeHead(code, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(obj));
}

http.createServer(async (req, res) => {
  const u = new URL(req.url, `http://${req.headers.host}`);

  if (u.pathname === "/" || u.pathname === "/index.html") {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    return fs.createReadStream(path.join(__dirname, "index.html")).pipe(res);
  }

  if (u.pathname === "/api/info") {
    const data = await downloadFacebook(u.searchParams.get("url"));
    return sendJson(res, data.status ? 200 : 400, data);
  }

  // Proxy supaya tombol download langsung menyimpan file (bukan membuka tab baru)
  if (u.pathname === "/api/dl") {
    try {
      const target = new URL(u.searchParams.get("u") || "");
      if (target.protocol !== "https:" || !ALLOWED_HOSTS.test(target.hostname))
        return sendJson(res, 400, { status: false, message: "Host tidak diizinkan." });
      const upstream = await fetch(target, { headers: { "User-Agent": "Mozilla/5.0" } });
      if (!upstream.ok || !upstream.body)
        return sendJson(res, 502, { status: false, message: "Gagal mengambil video." });
      const name = (u.searchParams.get("n") || "facebook-video").replace(/[^\w\- ]+/g, "").trim().slice(0, 80) || "facebook-video";
      const h = {
        "Content-Type": upstream.headers.get("content-type") || "video/mp4",
        "Content-Disposition": `attachment; filename="${name}.mp4"`
      };
      const len = upstream.headers.get("content-length");
      if (len) h["Content-Length"] = len;
      res.writeHead(200, h);
      return Readable.fromWeb(upstream.body).pipe(res);
    } catch {
      return sendJson(res, 400, { status: false, message: "Permintaan tidak valid." });
    }
  }

  res.writeHead(404); res.end("Not found");
}).listen(PORT, () => console.log(`Vexora FB Downloader jalan di http://localhost:${PORT}`));
