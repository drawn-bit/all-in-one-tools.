# Vexora FB Downloader

Downloader video & Reels Facebook (publik) dengan tampilan neon biru.

## A. Menjalankan tools (sekali di awal)
1. Install Node.js versi 18 atau lebih baru dari https://nodejs.org
2. Ekstrak file zip ini.
3. Buka terminal / CMD / Termux di dalam folder hasil ekstrak.
4. Ketik: node server.js
5. Kalau muncul "Vexora FB Downloader jalan di http://localhost:3000", berarti sudah aktif.
6. Buka http://localhost:3000 di browser. Biarkan terminal tetap terbuka.

(Ganti port: PORT=8080 node server.js)

## B. Mendownload video
1. Buka video atau Reels di Facebook, tekan Bagikan, lalu Salin link.
2. Tempel link di kolom yang tersedia.
3. Klik "Ambil video" dan tunggu pratinjau muncul.
4. Pilih Download HD (lebih jernih) atau Download SD (lebih kecil).
5. Video tersimpan di folder Download.

## Kalau gagal
- Pastikan video publik (bukan privat / grup tertutup).
- Pastikan terminal masih menjalankan node server.js.
- Kalau Facebook mengubah halamannya, pola regex di fungsi downloadFacebook perlu diperbarui.

Downloader core: Vamz Spectre (MIT)
Made in by Vexora Tools
