/**
 * Vexora Instagram Downloader - Reels, Video, Foto & Carousel (publik)
 * Logika ekstraksi: adaptasi dari Instagram Media Extractor (Vamz Spectre / Vamx)
 * UI & server: Vexora Tools
 * Jalankan: node server.js -> http://localhost:3000  (Node.js 18+, tanpa npm install)
 */
const http = require("http");
const fs = require("fs");
const path = require("path");
const { Readable } = require("stream");

const PORT = process.env.PORT || 3000;
const UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36";
const CDN_HOSTS = /(^|\.)(cdninstagram\.com|fbcdn\.net)$/i;

let session = null;
async function getSession() {
  const now = Date.now();
  if (session && session.exp > now && session.csrf) return session;
  const r = await fetch("https://www.instagram.com/", {
    headers: { "User-Agent": UA, Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", "Accept-Language": "en-US,en;q=0.8" },
    redirect: "manual",
    signal: AbortSignal.timeout(10000)
  });
  const raw = typeof r.headers.getSetCookie === "function" ? r.headers.getSetCookie() : [];
  const cookies = raw.map((c) => c.split(";")[0]).join("; ");
  const m = cookies.match(/csrftoken=([^;]+)/);
  session = { csrf: m ? m[1] : "", cookies, exp: now + 20 * 60 * 1000 };
  return session;
}

const getShortcode = (url) => {
  const m = url.match(/(?:p|reel|reels)\/([A-Za-z0-9_-]+)/);
  return m ? m[1] : null;
};
const pick = (n) => {
  const thumb = n.image_versions2?.candidates?.[0]?.url || null;
  if (n.video_versions?.length) return { type: "video", url: n.video_versions[0].url, thumb };
  if (thumb) return { type: "image", url: thumb, thumb };
  return null;
};

async function extractInstagramMedia(input) {
  const fail = (message) => ({ status: false, message });
  try {
    let url = String(input || "").trim();
    if (!/instagram\.com/i.test(url)) return fail("Link harus dari instagram.com.");
    if (/instagram\.com\/share\//i.test(url)) {
      const r = await fetch(url, { headers: { "User-Agent": UA }, redirect: "follow", signal: AbortSignal.timeout(10000) });
      url = r.url || url;
    }
    const code = getShortcode(url);
    if (!code) return fail("Link tidak dikenali. Pakai link post atau Reels (instagram.com/p/... atau /reel/...).");

    const post = async (s) => {
      const body = new URLSearchParams({
        variables: JSON.stringify({ shortcode: code, __relay_internal__pv__PolarisAIGMMediaWebLabelEnabledrelayprovider: false }),
        doc_id: "27128499623469141",
        server_timestamps: "true"
      });
      const r = await fetch("https://www.instagram.com/graphql/query", {
        method: "POST",
        headers: {
          "User-Agent": UA, Accept: "*/*", "Accept-Language": "en-US,en;q=0.8",
          "Content-Type": "application/x-www-form-urlencoded",
          "X-CSRFToken": s.csrf, "X-IG-App-ID": "936619743392459",
          Cookie: s.cookies, Referer: `https://www.instagram.com/p/${code}/`
        },
        body: body.toString(),
        signal: AbortSignal.timeout(15000)
      });
      let j = null;
      try { j = await r.json(); } catch {}
      return { ok: r.ok, j };
    };

    let s = await getSession();
    let r = await post(s);
    if (!r.ok || !r.j?.data) { session = null; s = await getSession(); r = await post(s); }

    const item = r.j?.data?.xdt_api__v1__media__shortcode__web_info?.items?.[0];
    if (!item) return fail("Media tidak ditemukan atau akun privat.");

    const nodes = Array.isArray(item.carousel_media) && item.carousel_media.length ? item.carousel_media : [item];
    const items = nodes.map(pick).filter(Boolean);
    if (!items.length) return fail("Link download media tidak ditemukan.");

    return {
      status: true,
      result: {
        username: item.user?.username || "-",
        full_name: item.user?.full_name || "",
        caption: item.caption?.text || "",
        likes: item.like_count ?? 0,
        comments: item.comment_count ?? 0,
        items
      }
    };
  } catch (err) {
    return fail(err.message || "Gagal mengekstrak media Instagram.");
  }
}

const json = (res, code, obj) => {
  res.writeHead(code, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(obj));
};

http.createServer(async (req, res) => {
  const u = new URL(req.url, `http://${req.headers.host}`);

  if (u.pathname === "/" || u.pathname === "/index.html") {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    return fs.createReadStream(path.join(__dirname, "index.html")).pipe(res);
  }

  if (u.pathname === "/api/info") {
    const data = await extractInstagramMedia(u.searchParams.get("url"));
    return json(res, data.status ? 200 : 400, data);
  }

  // Proxy media (hanya CDN Instagram): inline=1 untuk pratinjau, tanpa itu langsung terunduh
  if (u.pathname === "/api/dl") {
    try {
      const target = new URL(u.searchParams.get("u") || "");
      if (target.protocol !== "https:" || !CDN_HOSTS.test(target.hostname))
        return json(res, 400, { status: false, message: "Host tidak diizinkan." });
      const h = { "User-Agent": UA, Referer: "https://www.instagram.com/" };
      if (req.headers.range) h.Range = req.headers.range;
      const up = await fetch(target, { headers: h });
      if (!up.ok || !up.body) return json(res, 502, { status: false, message: "Gagal mengambil media." });

      const type = up.headers.get("content-type") || "application/octet-stream";
      const ext = type.includes("video") ? "mp4" : type.includes("webp") ? "webp" : type.includes("png") ? "png" : "jpg";
      const name = (u.searchParams.get("n") || "instagram").replace(/[^\w\- ]+/g, "").trim().slice(0, 60) || "instagram";
      const out = {
        "Content-Type": type,
        "Content-Disposition": `${u.searchParams.get("inline") ? "inline" : "attachment"}; filename="${name}.${ext}"`,
        "Accept-Ranges": "bytes"
      };
      for (const k of ["content-length", "content-range"]) if (up.headers.get(k)) out[k] = up.headers.get(k);
      res.writeHead(up.status, out);
      return Readable.fromWeb(up.body).pipe(res);
    } catch {
      return json(res, 400, { status: false, message: "Permintaan tidak valid." });
    }
  }

  res.writeHead(404); res.end("Not found");
}).listen(PORT, () => console.log(`Vexora Instagram Downloader jalan di http://localhost:${PORT}`));
