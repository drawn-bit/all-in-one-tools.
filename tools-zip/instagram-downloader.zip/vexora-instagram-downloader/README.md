# Vexora Instagram Downloader

Simpan Reels, video, foto, dan carousel dari akun Instagram publik.

## A. Menjalankan (sekali di awal)
1. Install Node.js 18 atau lebih baru dari https://nodejs.org
2. Ekstrak zip ini, buka terminal / CMD / Termux di foldernya.
3. Ketik: node server.js
4. Kalau muncul "Vexora Instagram Downloader jalan di http://localhost:3000", sudah aktif. Biarkan terminal terbuka.
5. Buka http://localhost:3000 di browser.

## B. Mendownload
1. Di Instagram: buka post/Reels, tekan Bagikan, lalu Salin link.
2. Tempel link di kolom, klik "Ambil media".
3. Tekan Download di video/foto yang diinginkan.
4. File tersimpan di folder Download.

## Kalau gagal
- Akun harus publik. Post privat tidak bisa diambil.
- Pastikan terminal masih menjalankan node server.js.
- Instagram sering mengubah sistemnya; kalau gagal terus, doc_id di server.js perlu diperbarui.

Logika ekstraksi: Vamz Spectre / Vamx
Made in by Vexora Tools
