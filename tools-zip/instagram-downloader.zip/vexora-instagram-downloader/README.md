# Vexora Instagram Downloader

Halaman: index.html | Backend (Vercel Functions): api/ig-info.js dan api/ig-dl.js

## Deploy ke Vercel
1. EKSTRAK dulu zip ini, lalu upload ISI-nya (index.html, package.json, folder api/) ke repo GitHub. Jangan upload file .zip-nya.
   index.html dan folder api/ harus ada di paling atas repo (atau atur "Root Directory" di Vercel).
2. Vercel > Add New Project > pilih repo > Framework Preset: Other > Deploy.
3. Kalau dipasang di project hub yang sudah ada, salin file di folder api/ ke folder api/ di ROOT repo hub.
   Kalau halaman ada di domain lain, isi API_BASE di index.html dengan alamat project yang punya folder api/.

## Jalan lokal (Termux / PC)
node server.js -> http://localhost:3000 (Node.js 18+)

Made in by Vexora Tools
