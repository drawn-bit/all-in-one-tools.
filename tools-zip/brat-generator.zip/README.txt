Vexora Brat Generator
Buka index.html di browser (Chrome/Edge/Safari). Tidak perlu server atau internet.
Upload folder ini ke hosting statis (Netlify, Vercel, GitHub Pages) kalau mau online.
