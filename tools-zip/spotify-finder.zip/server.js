/** Jalan lokal: node server.js -> http://localhost:3000 (di Vercel dipakai folder api/) */
const http = require("http");
const fs = require("fs");
const path = require("path");

function adapt(handler) {
  return (req, res) => {
    const u = new URL(req.url, `http://${req.headers.host}`);
    req.query = Object.fromEntries(u.searchParams);
    res.status = (c) => { res.statusCode = c; return res; };
    res.json = (o) => { res.setHeader("Content-Type", "application/json; charset=utf-8"); res.end(JSON.stringify(o)); };
    return handler(req, res);
  };
}
const routes = { "/api/sp-search": adapt(require("./api/sp-search")) };

http.createServer((req, res) => {
  const p = new URL(req.url, `http://${req.headers.host}`).pathname;
  if (routes[p]) return routes[p](req, res);
  if (p === "/" || p === "/index.html") {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    return fs.createReadStream(path.join(__dirname, "index.html")).pipe(res);
  }
  res.writeHead(404); res.end("Not found");
}).listen(process.env.PORT || 3000, () => console.log("Vexora Spotify Finder jalan di http://localhost:" + (process.env.PORT || 3000)));
