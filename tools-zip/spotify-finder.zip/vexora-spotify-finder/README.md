# Vexora Spotify Finder

Cari lagu, lihat info lengkap (cover HD, artis, album, durasi), putar pratinjau 30 detik.

## A. Menjalankan (sekali di awal)
1. Install Node.js 18 atau lebih baru dari https://nodejs.org
2. Ekstrak zip ini, buka terminal / CMD / Termux di foldernya.
3. Ketik: node server.js
4. Kalau muncul "Vexora Spotify Finder jalan di http://localhost:3000", sudah aktif. Biarkan terminal terbuka.
5. Buka http://localhost:3000 di browser.

## B. Memakai
1. Ketik judul lagu / artis, atau tempel link lagu Spotify.
2. Klik "Cari lagu".
3. Tekan "Putar" untuk pratinjau 30 detik.
4. Tekan "Buka di Spotify" untuk lagu penuh.

Made in by Vexora Tools
